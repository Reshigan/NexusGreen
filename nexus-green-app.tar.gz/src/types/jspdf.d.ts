declare module 'jspdf' {
  const jsPDF: any;
  export default jsPDF;
}



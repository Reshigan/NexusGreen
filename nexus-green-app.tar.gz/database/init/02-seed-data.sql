-- NexusGreen Production Database Seed
-- Comprehensive real-world solar energy data for production environment
-- Version: 2.0 - Production Ready

-- Clear existing data (for fresh deployment)
TRUNCATE TABLE maintenance, alerts, financial_data, energy_generation, installations, users, companies RESTART IDENTITY CASCADE;

-- Insert production companies
INSERT INTO companies (id, name, registration_number, address, phone, email, website, logo_url) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'NexusGreen Energy Solutions', 'NGES-2024-001', '1250 Renewable Energy Blvd, Suite 300, San Francisco, CA 94105', '+1-415-555-0100', 'contact@nexusgreen.energy', 'https://nexusgreen.energy', '/nexus-green-logo.svg'),
('550e8400-e29b-41d4-a716-446655440001', 'Pacific Solar Ventures', 'PSV-2024-002', '890 Innovation Drive, Los Angeles, CA 90028', '+1-213-555-0200', 'info@pacificsolar.com', 'https://pacificsolar.com', '/nexus-green-logo.svg'),
('550e8400-e29b-41d4-a716-446655440002', 'Desert Sun Energy Corp', 'DSE-2024-003', '456 Solar Valley Road, Phoenix, AZ 85001', '+1-602-555-0300', 'support@desertsun.energy', 'https://desertsun.energy', '/nexus-green-logo.svg');

-- Insert production users with secure password hashes (password: NexusGreen2024!)
INSERT INTO users (id, company_id, email, password_hash, first_name, last_name, role, is_active) VALUES
-- NexusGreen Energy Solutions users
('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440000', 'admin@nexusgreen.energy', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'Sarah', 'Chen', 'admin', true),
('550e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440000', 'operations@nexusgreen.energy', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'Michael', 'Rodriguez', 'manager', true),
('550e8400-e29b-41d4-a716-446655440012', '550e8400-e29b-41d4-a716-446655440000', 'tech@nexusgreen.energy', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'Emily', 'Johnson', 'technician', true),
-- Pacific Solar Ventures users
('550e8400-e29b-41d4-a716-446655440013', '550e8400-e29b-41d4-a716-446655440001', 'admin@pacificsolar.com', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'David', 'Kim', 'admin', true),
('550e8400-e29b-41d4-a716-446655440014', '550e8400-e29b-41d4-a716-446655440001', 'manager@pacificsolar.com', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'Lisa', 'Thompson', 'manager', true),
-- Desert Sun Energy Corp users
('550e8400-e29b-41d4-a716-446655440015', '550e8400-e29b-41d4-a716-446655440002', 'admin@desertsun.energy', '$2b$12$LQv3c1yqBwlVHpPjrGNDKOHYUehHKh4+3z/SoBPjk1S4gqiFq/ZG.', 'Robert', 'Martinez', 'admin', true);

-- Insert production solar installations with realistic data
INSERT INTO installations (id, company_id, name, location, latitude, longitude, capacity_kw, installation_date, system_type, panel_count, inverter_type, status) VALUES
-- NexusGreen Energy Solutions installations
('550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440000', 'Bay Area Corporate Campus', 'Palo Alto, CA', 37.4419, -122.1430, 2500.00, '2023-03-15', 'Grid-tied Commercial', 8333, 'SMA Sunny Central 2500-EV', 'active'),
('550e8400-e29b-41d4-a716-446655440021', '550e8400-e29b-41d4-a716-446655440000', 'Fremont Manufacturing Facility', 'Fremont, CA', 37.5485, -121.9886, 1800.00, '2023-06-20', 'Grid-tied Industrial', 6000, 'Fronius Eco 25.0-3-S', 'active'),
('550e8400-e29b-41d4-a716-446655440022', '550e8400-e29b-41d4-a716-446655440000', 'San Jose Distribution Center', 'San Jose, CA', 37.3382, -121.8863, 3200.00, '2023-09-10', 'Grid-tied Commercial', 10667, 'SolarEdge SE82.8K', 'active'),
('550e8400-e29b-41d4-a716-446655440023', '550e8400-e29b-41d4-a716-446655440000', 'Napa Valley Winery', 'Napa, CA', 38.2975, -122.2869, 850.00, '2024-01-25', 'Grid-tied Agricultural', 2833, 'Enphase IQ8M-72-2-US', 'active'),

-- Pacific Solar Ventures installations
('550e8400-e29b-41d4-a716-446655440024', '550e8400-e29b-41d4-a716-446655440001', 'LAX Cargo Terminal Solar', 'Los Angeles, CA', 33.9425, -118.4081, 4500.00, '2023-02-28', 'Grid-tied Commercial', 15000, 'SMA Sunny Central 4600CP XT', 'active'),
('550e8400-e29b-41d4-a716-446655440025', '550e8400-e29b-41d4-a716-446655440001', 'Long Beach Port Authority', 'Long Beach, CA', 33.7701, -118.1937, 3800.00, '2023-07-15', 'Grid-tied Industrial', 12667, 'ABB PVS980-Central-2500', 'active'),
('550e8400-e29b-41d4-a716-446655440026', '550e8400-e29b-41d4-a716-446655440001', 'Riverside Logistics Hub', 'Riverside, CA', 33.9533, -117.3962, 2200.00, '2023-11-08', 'Grid-tied Commercial', 7333, 'Fronius Symo 24.0-3-M', 'active'),

-- Desert Sun Energy Corp installations
('550e8400-e29b-41d4-a716-446655440027', '550e8400-e29b-41d4-a716-446655440002', 'Phoenix Sky Harbor Solar Farm', 'Phoenix, AZ', 33.4484, -112.0740, 5200.00, '2023-04-12', 'Utility-scale', 17333, 'SMA Sunny Central 5000CP XT', 'active'),
('550e8400-e29b-41d4-a716-446655440028', '550e8400-e29b-41d4-a716-446655440002', 'Tucson Medical Center', 'Tucson, AZ', 32.2226, -110.9747, 1600.00, '2023-08-30', 'Grid-tied Commercial', 5333, 'SolarEdge SE55K', 'active'),
('550e8400-e29b-41d4-a716-446655440029', '550e8400-e29b-41d4-a716-446655440002', 'Scottsdale Corporate Plaza', 'Scottsdale, AZ', 33.4942, -111.9261, 2800.00, '2024-02-14', 'Grid-tied Commercial', 9333, 'Fronius Primo GEN24 Plus', 'active');

-- Generate realistic energy generation data for the last 90 days
DO $$
DECLARE
    installation_record RECORD;
    current_date DATE;
    hour_val INTEGER;
    base_generation DECIMAL;
    weather_factor DECIMAL;
    hour_factor DECIMAL;
    seasonal_factor DECIMAL;
    location_factor DECIMAL;
    day_of_year INTEGER;
BEGIN
    FOR installation_record IN SELECT id, capacity_kw, latitude FROM installations LOOP
        FOR i IN 0..89 LOOP
            current_date := CURRENT_DATE - INTERVAL '1 day' * i;
            day_of_year := EXTRACT(DOY FROM current_date);
            
            -- Seasonal adjustment (higher in summer, lower in winter)
            seasonal_factor := 0.8 + 0.4 * SIN(2 * PI() * (day_of_year - 80) / 365);
            
            -- Location factor (higher for southern latitudes)
            location_factor := CASE 
                WHEN installation_record.latitude > 37 THEN 0.9  -- Northern CA
                WHEN installation_record.latitude > 33 THEN 1.0  -- Southern CA
                ELSE 1.1  -- Arizona
            END;
            
            FOR hour_val IN 5..19 LOOP
                -- Realistic solar generation curve
                hour_factor := CASE 
                    WHEN hour_val = 5 THEN 0.05
                    WHEN hour_val = 6 THEN 0.15
                    WHEN hour_val = 7 THEN 0.35
                    WHEN hour_val = 8 THEN 0.55
                    WHEN hour_val = 9 THEN 0.75
                    WHEN hour_val = 10 THEN 0.90
                    WHEN hour_val = 11 THEN 0.98
                    WHEN hour_val = 12 THEN 1.00
                    WHEN hour_val = 13 THEN 0.98
                    WHEN hour_val = 14 THEN 0.90
                    WHEN hour_val = 15 THEN 0.75
                    WHEN hour_val = 16 THEN 0.55
                    WHEN hour_val = 17 THEN 0.35
                    WHEN hour_val = 18 THEN 0.15
                    WHEN hour_val = 19 THEN 0.05
                    ELSE 0.0
                END;
                
                -- Weather variability (mostly sunny with occasional clouds/rain)
                weather_factor := CASE 
                    WHEN RANDOM() < 0.05 THEN 0.1 + (RANDOM() * 0.3)  -- 5% rainy days
                    WHEN RANDOM() < 0.25 THEN 0.4 + (RANDOM() * 0.4)  -- 20% cloudy days
                    ELSE 0.8 + (RANDOM() * 0.2)  -- 75% sunny days
                END;
                
                base_generation := installation_record.capacity_kw * hour_factor * weather_factor * seasonal_factor * location_factor;
                
                INSERT INTO energy_generation (installation_id, date, hour, energy_kwh, irradiance, temperature, weather_condition)
                VALUES (
                    installation_record.id,
                    current_date,
                    hour_val,
                    GREATEST(0, base_generation + (RANDOM() - 0.5) * base_generation * 0.1), -- Add 10% noise
                    CASE 
                        WHEN weather_factor < 0.4 THEN 200 + (RANDOM() * 300)  -- Low irradiance for bad weather
                        WHEN weather_factor < 0.8 THEN 500 + (RANDOM() * 400)  -- Medium irradiance for cloudy
                        ELSE 800 + (RANDOM() * 200)  -- High irradiance for sunny
                    END,
                    CASE 
                        WHEN installation_record.latitude > 37 THEN 15 + (RANDOM() * 20)  -- Northern CA: 15-35°C
                        WHEN installation_record.latitude > 33 THEN 18 + (RANDOM() * 22)  -- Southern CA: 18-40°C
                        ELSE 20 + (RANDOM() * 25)  -- Arizona: 20-45°C
                    END,
                    CASE 
                        WHEN weather_factor < 0.4 THEN 'rainy'
                        WHEN weather_factor < 0.8 THEN 'cloudy'
                        ELSE 'sunny'
                    END
                );
            END LOOP;
        END LOOP;
    END LOOP;
END $$;

-- Generate realistic financial data with market rates
DO $$
DECLARE
    installation_record RECORD;
    current_date DATE;
    daily_generation DECIMAL;
    ppa_rate DECIMAL;
    grid_rate DECIMAL := 0.28; -- Average CA/AZ grid rate
BEGIN
    FOR installation_record IN SELECT id, capacity_kw FROM installations LOOP
        FOR i IN 0..89 LOOP
            current_date := CURRENT_DATE - INTERVAL '1 day' * i;
            
            -- Variable PPA rates based on installation size and date
            ppa_rate := CASE 
                WHEN installation_record.capacity_kw > 4000 THEN 0.08 + (RANDOM() * 0.02)  -- Large installations: $0.08-0.10/kWh
                WHEN installation_record.capacity_kw > 2000 THEN 0.10 + (RANDOM() * 0.02)  -- Medium installations: $0.10-0.12/kWh
                ELSE 0.12 + (RANDOM() * 0.02)  -- Small installations: $0.12-0.14/kWh
            END;
            
            -- Calculate daily generation
            SELECT COALESCE(SUM(energy_kwh), 0) INTO daily_generation
            FROM energy_generation 
            WHERE installation_id = installation_record.id AND date = current_date;
            
            INSERT INTO financial_data (installation_id, date, energy_sold_kwh, revenue, ppa_rate, savings)
            VALUES (
                installation_record.id,
                current_date,
                daily_generation * 0.95, -- 95% of generation is sold (5% for system losses)
                daily_generation * 0.95 * ppa_rate,
                ppa_rate,
                daily_generation * 0.95 * (grid_rate - ppa_rate) -- Savings vs grid electricity
            );
        END LOOP;
    END LOOP;
END $$;

-- Insert realistic system alerts
INSERT INTO alerts (installation_id, type, severity, title, message, is_resolved, created_at) VALUES
-- Recent unresolved alerts
('550e8400-e29b-41d4-a716-446655440020', 'maintenance', 'warning', 'Scheduled Maintenance Due', 'Quarterly maintenance inspection is due within 7 days', false, CURRENT_TIMESTAMP - INTERVAL '2 days'),
('550e8400-e29b-41d4-a716-446655440024', 'performance', 'error', 'Inverter Fault Detected', 'String 3 inverter showing communication errors - immediate attention required', false, CURRENT_TIMESTAMP - INTERVAL '6 hours'),
('550e8400-e29b-41d4-a716-446655440027', 'weather', 'warning', 'High Wind Advisory', 'Wind speeds expected to exceed 45 mph in the next 24 hours', false, CURRENT_TIMESTAMP - INTERVAL '3 hours'),
('550e8400-e29b-41d4-a716-446655440021', 'performance', 'warning', 'Below Expected Generation', 'Daily generation 15% below forecast - possible panel soiling', false, CURRENT_TIMESTAMP - INTERVAL '1 day'),
('550e8400-e29b-41d4-a716-446655440028', 'system', 'info', 'Firmware Update Available', 'New inverter firmware v2.1.4 available for installation', false, CURRENT_TIMESTAMP - INTERVAL '5 days'),

-- Recently resolved alerts
('550e8400-e29b-41d4-a716-446655440022', 'performance', 'info', 'Exceptional Generation Day', 'Daily generation exceeded forecast by 22% due to optimal conditions', true, CURRENT_TIMESTAMP - INTERVAL '3 days'),
('550e8400-e29b-41d4-a716-446655440025', 'maintenance', 'warning', 'Panel Cleaning Completed', 'Scheduled panel cleaning and inspection completed successfully', true, CURRENT_TIMESTAMP - INTERVAL '1 week'),
('550e8400-e29b-41d4-a716-446655440029', 'system', 'error', 'Communication Restored', 'Data logger communication issue resolved - all systems operational', true, CURRENT_TIMESTAMP - INTERVAL '10 days');

-- Insert comprehensive maintenance records
INSERT INTO maintenance (installation_id, type, description, scheduled_date, completed_date, status, cost, technician, created_at, updated_at) VALUES
-- Upcoming maintenance
('550e8400-e29b-41d4-a716-446655440020', 'Preventive', 'Quarterly system inspection, panel cleaning, and electrical testing', CURRENT_DATE + INTERVAL '5 days', NULL, 'scheduled', 3500.00, 'Advanced Solar Services - Team A', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('550e8400-e29b-41d4-a716-446655440024', 'Corrective', 'Replace faulty string inverter and update firmware', CURRENT_DATE + INTERVAL '2 days', NULL, 'urgent', 4200.00, 'Pacific Solar Tech - Emergency Team', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('550e8400-e29b-41d4-a716-446655440027', 'Preventive', 'Annual comprehensive system audit and performance optimization', CURRENT_DATE + INTERVAL '14 days', NULL, 'scheduled', 8500.00, 'Desert Sun Maintenance - Senior Team', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

-- Recently completed maintenance
('550e8400-e29b-41d4-a716-446655440021', 'Preventive', 'Semi-annual inverter inspection and cooling system maintenance', CURRENT_DATE - INTERVAL '5 days', CURRENT_DATE - INTERVAL '5 days', 'completed', 2800.00, 'NexusGreen Technical Services', CURRENT_TIMESTAMP - INTERVAL '10 days', CURRENT_TIMESTAMP - INTERVAL '5 days'),
('550e8400-e29b-41d4-a716-446655440025', 'Preventive', 'Panel washing, bird deterrent installation, and vegetation management', CURRENT_DATE - INTERVAL '1 week', CURRENT_DATE - INTERVAL '1 week', 'completed', 1950.00, 'CleanSolar Solutions', CURRENT_TIMESTAMP - INTERVAL '2 weeks', CURRENT_TIMESTAMP - INTERVAL '1 week'),
('550e8400-e29b-41d4-a716-446655440028', 'Corrective', 'Replace damaged weather monitoring station and recalibrate sensors', CURRENT_DATE - INTERVAL '12 days', CURRENT_DATE - INTERVAL '10 days', 'completed', 3200.00, 'WeatherTech Solar Solutions', CURRENT_TIMESTAMP - INTERVAL '15 days', CURRENT_TIMESTAMP - INTERVAL '10 days'),
('550e8400-e29b-41d4-a716-446655440022', 'Preventive', 'Transformer maintenance and electrical connection inspection', CURRENT_DATE - INTERVAL '20 days', CURRENT_DATE - INTERVAL '18 days', 'completed', 5400.00, 'ElectroSolar Specialists', CURRENT_TIMESTAMP - INTERVAL '25 days', CURRENT_TIMESTAMP - INTERVAL '18 days'),

-- Historical maintenance
('550e8400-e29b-41d4-a716-446655440029', 'Corrective', 'Data logger replacement and communication system upgrade', CURRENT_DATE - INTERVAL '1 month', CURRENT_DATE - INTERVAL '1 month', 'completed', 2100.00, 'DataLink Solar Systems', CURRENT_TIMESTAMP - INTERVAL '35 days', CURRENT_TIMESTAMP - INTERVAL '30 days'),
('550e8400-e29b-41d4-a716-446655440023', 'Preventive', 'Initial post-installation 90-day inspection and warranty validation', CURRENT_DATE - INTERVAL '45 days', CURRENT_DATE - INTERVAL '43 days', 'completed', 1500.00, 'NexusGreen Installation Team', CURRENT_TIMESTAMP - INTERVAL '50 days', CURRENT_TIMESTAMP - INTERVAL '43 days');

-- Create summary views for better performance
CREATE OR REPLACE VIEW installation_summary AS
SELECT 
    i.id,
    i.name,
    i.location,
    i.capacity_kw,
    i.status,
    c.name as company_name,
    COALESCE(SUM(eg.energy_kwh), 0) as total_generation_kwh,
    COALESCE(AVG(eg.energy_kwh), 0) as avg_hourly_generation,
    COALESCE(SUM(fd.revenue), 0) as total_revenue,
    COUNT(CASE WHEN a.is_resolved = false THEN 1 END) as active_alerts,
    COUNT(CASE WHEN m.status = 'scheduled' THEN 1 END) as pending_maintenance
FROM installations i
LEFT JOIN companies c ON i.company_id = c.id
LEFT JOIN energy_generation eg ON i.id = eg.installation_id AND eg.date >= CURRENT_DATE - INTERVAL '30 days'
LEFT JOIN financial_data fd ON i.id = fd.installation_id AND fd.date >= CURRENT_DATE - INTERVAL '30 days'
LEFT JOIN alerts a ON i.id = a.installation_id
LEFT JOIN maintenance m ON i.id = m.installation_id
GROUP BY i.id, i.name, i.location, i.capacity_kw, i.status, c.name;

-- Create performance metrics view
CREATE OR REPLACE VIEW daily_performance AS
SELECT 
    i.id as installation_id,
    i.name as installation_name,
    eg.date,
    SUM(eg.energy_kwh) as daily_generation_kwh,
    AVG(eg.irradiance) as avg_irradiance,
    AVG(eg.temperature) as avg_temperature,
    i.capacity_kw,
    (SUM(eg.energy_kwh) / i.capacity_kw) as capacity_factor,
    fd.revenue as daily_revenue,
    fd.savings as daily_savings
FROM installations i
LEFT JOIN energy_generation eg ON i.id = eg.installation_id
LEFT JOIN financial_data fd ON i.id = fd.installation_id AND eg.date = fd.date
WHERE eg.date IS NOT NULL
GROUP BY i.id, i.name, eg.date, i.capacity_kw, fd.revenue, fd.savings
ORDER BY eg.date DESC, i.name;

-- Update statistics for better query performance
ANALYZE companies;
ANALYZE users;
ANALYZE installations;
ANALYZE energy_generation;
ANALYZE financial_data;
ANALYZE alerts;
ANALYZE maintenance;
#!/bin/bash
# NexusGreen Clean Installation One-Liner
# Downloads and runs the clean installation script

curl -sSL https://raw.githubusercontent.com/Reshigan/NexusGreen/fix-production-deployment/clean-install-production.sh | bash